#hello.py
def hello():
    print("Hello python!")