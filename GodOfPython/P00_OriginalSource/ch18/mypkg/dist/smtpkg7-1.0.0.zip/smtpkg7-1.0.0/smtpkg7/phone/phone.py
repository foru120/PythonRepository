#phone.py
def makeacall():
    print("Make a Call")

if __name__ == '__main__':
    makeacall()
